//
//  main.m
//  ClassMethod
//
//  Created by Azad on 13/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Bank Account.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Bank_Account *account1, *account2;
        
        account1 = [[Bank_Account account] init];
        account2 = [[Bank_Account account] init];
        
        int count = [Bank_Account totalOpen];
        
        NSLog (@"Number of BankAccount instances = %i", count);
    }
    return 0;
}
