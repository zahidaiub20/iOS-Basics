//
//  Rectangle.m
//  ObjectInitialize
//
//  Created by Azad on 10/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "Rectangle.h"

@implementation Rectangle

-(id)init
{
    self=[super init];
    if (self)
    {
        _height=10;
        _width=8;
    }
    return self;
}

@end
