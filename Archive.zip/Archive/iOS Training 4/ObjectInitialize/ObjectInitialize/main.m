//
//  main.m
//  ObjectInitialize
//
//  Created by Azad on 10/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Rectangle.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Rectangle *myRect=[[Rectangle alloc]init];
//        NSLog(@"%i",[Rectangle m]);
        NSLog(@"%@",myRect);
//        NSLog(@"%i and %i",[myRect height],[myRect width]);
//        NSLog(@"%@",myRect);
    }
    return 0;
}
