//
//  ViewController.m
//  TableViewWithImage
//
//  Created by Azad on 13/8/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController
{
    NSArray *arrayItem;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.dataSource= self;
    self.tableView.delegate= self;
    
    arrayItem=[NSArray arrayWithObjects:@"ekra", @"Taufique",@"Ashik",@"Nayem", @"Hasib",nil];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayItem count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableCellIdentifier=@"tableCellIdentifier";
    NSString *cellItem=[arrayItem objectAtIndex:indexPath.row];
    
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:simpleTableCellIdentifier];
    
    if(cell==nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableCellIdentifier];
    }
    cell.textLabel.text=cellItem;
//    cell.imageView.image=[UIImage imageNamed:@"images.jpeg"];
    return cell;
}

@end
