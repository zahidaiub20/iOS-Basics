//
//  main.m
//  ArrayInitializers
//
//  Created by Azad on 4/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        NSString *firstString=@"First String";
        NSString *secondString=@"Second String";
        
        NSArray *myArray=[[NSArray alloc]initWithObjects:firstString, secondString, nil];
//        NSArray *myArray=@[@"first",@[firstString],@[secondString]];
//        NSLog(@"%@",myArray);
        
        NSMutableArray *myMutableArray=[[NSMutableArray alloc]initWithObjects:firstString, secondString, myArray, nil];
        NSLog(@"%@",myMutableArray);

    }
    return 0;
}
