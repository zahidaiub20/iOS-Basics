//
//  ViewController.h
//  xyzSqlite
//
//  Created by Admin on 30/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
//#import "/usr/include/sqlite3.h"

@interface ViewController : UIViewController
{
    //    The application user interface is goint to consist of three text fields(for the name address and phone number), a label object to display the status of the database activities, a Save button and a Find button. When clicked the save button will write the data entered into the text fields into a database table. The find, on the other hand, will search the database for row that matches the currently entered contact name and display the address and phone number for the matching record in the address and phone text fields.
    //    UITextField *name;
    //    UITextField *address;
    //    UITextField *phone;
    //    UILabel * status;
    NSString * databasePath;
    //    Before we can create a database we need to declare a variable pointer to a structure of type sqlite3 that will act as the reference to our database.
    sqlite3 *contactDB;
}
@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *address;
@property (strong, nonatomic) IBOutlet UITextField *phone;
@property (strong, nonatomic) IBOutlet UILabel *status;

- (IBAction)saveData:(UIButton *)sender;
- (IBAction)findContact:(UIButton *)sender;

@end

