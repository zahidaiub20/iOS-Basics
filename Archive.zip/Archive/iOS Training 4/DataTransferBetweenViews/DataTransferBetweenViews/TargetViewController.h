//
//  TargetViewController.h
//  DataTransferBetweenViews
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface TargetViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UILabel *addressLabel;
@property (strong, nonatomic) IBOutlet UILabel *numberLabel;

@property (strong, nonatomic) NSString *strName;
@property (strong, nonatomic) NSString *strAddress;
@property (strong, nonatomic) NSString *strNumber;


@end


