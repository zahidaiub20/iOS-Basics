//
//  ViewController.h
//  DataTransferBetweenViews
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *textFieldName;
@property (strong, nonatomic) IBOutlet UITextField *textFieldAddress;
@property (strong, nonatomic) IBOutlet UITextField *textFieldNumber;
- (IBAction)submitButton:(UIButton *)sender;

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender;
@end

