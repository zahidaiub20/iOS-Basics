//
//  main.m
//  NSArray
//
//  Created by Azad on 13/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
//        Accessing the Elements of an Array Object
        NSArray *myColours;
        int i;
        NSUInteger count;
        
        myColours = [NSArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", nil];
        count = [myColours count];
        
        for (i = 0; i < count; i++)
            NSLog (@"Element %i = %@", i, [myColours objectAtIndex: i]);
        
//        Accessing Array Elements using Fast Enumeration
        NSArray *myColors;
        NSString *color;
        
        myColors = [NSArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", nil];
        
        for (color in myColors)
            NSLog (@"Element = %@", color);
        
//        Adding Elements to an Array Object
        NSMutableArray *myColorss;
        
        myColorss = [NSMutableArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", nil];
        
        [myColorss addObject: @"Indigo"];
        [myColorss addObject: @"Violet"];
        
//        Inserting Elements into an Array
//  The previous method appends new objects onto the end of an array. It is also possible to insert                 new objects at specific index points in an array object using the insertObject instance method. This method accepts as arguments the object to be inserted and the index position at which the insertion is to take place:
        NSMutableArray *myColores;
        int j;
        NSUInteger countt;
        
        myColors = [NSMutableArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", nil];
        
        [myColores insertObject: @"Indigo" atIndex: 1];
        [myColores insertObject: @"Violet" atIndex: 3];
        
        countt = [myColores count];
        
        for (j = 0; j < count; j++)
            NSLog (@"Element %i = %@", j, [myColores objectAtIndex: j]);
        
//        Deleting Elements from an Array Object
        
//        To remove an element at a specific index location, use the removeObjectAtIndex method:
        NSMutableArray *myColeros;
        myColeros = [NSMutableArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", nil];
        
        [myColeros removeObjectAtIndex: 0];
        
//        To remove the first instance of a specific object from an array use removeObject:
        NSMutableArray *colors = [NSMutableArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", nil];
        
        [colors removeObject: @"Red"];
        
//        To remove all instances of a specific object in an array, use removeObjectIdenticalTo:
        NSMutableArray* colours = [NSMutableArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", @"Red", @"Red", nil];
        
        [colours removeObjectIdenticalTo: @"Red"];
        
//        To remove all objects from an array, use removeAllObjects:
        NSMutableArray* colores = [NSMutableArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", nil];
        
        [colores removeAllObjects];
        
//        To remove the last object in the array, use the removeLastObject method:
       NSMutableArray *myCoelors = [NSMutableArray arrayWithObjects: @"Red", @"Green", @"Blue", @"Yellow", nil];
        
        [myCoelors removeLastObject];
        
//        Sorting Array Objects
//        As we can see from the below example, the method returns a new array containing the elements of the original array sorted using the localizedCaseInsensitiveCompare method. In practice any method can be used in this context as long as that method is able to compare two objects and return an NSOrderedAscending, NSOrderedSame or NSOrderedDescending result.
        NSMutableArray *myCeolors = [NSMutableArray arrayWithObjects: @"red", @"green", @"blue", @"yellow", nil];
        
        NSArray *sortedArray;
        
        sortedArray = [myCeolors sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
        NSLog(@"the sorted array is %@",sortedArray);
    }
    return 0;
}
