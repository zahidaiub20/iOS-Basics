//
//  ViewController.m
//  PassingDataBetweenSegue
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "ViewController.h"
#import "Second ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
// Creating a Method about a segue
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"letsContinue"])
    {
        Second_ViewController *controller=(Second_ViewController *)segue.destinationViewController;
        controller.textContent=self.TextField.text;
    }
}

@end
