//
//  Second ViewController.m
//  PassingDataBetweenSegue
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "Second ViewController.h"

@interface Second_ViewController ()

@end

@implementation Second_ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.LabelView.text=self.textContent;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
