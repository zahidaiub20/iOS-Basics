//
//  TargetViewController.m
//  DataTransfer
//
//  Created by Admin on 12/9/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import "TargetViewController.h"

@interface TargetViewController ()

@end

@implementation TargetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.nameLabel.text=_strNameLabel;
    self.addressLabel.text=_strAddressLabel;
    self.numberLabel.text=_strNumberLabel;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
