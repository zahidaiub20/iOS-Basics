//
//  ViewController.m
//  DataTransfer
//
//  Created by Admin on 12/9/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import "ViewController.h"
#import "TargetViewController.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)submitButton:(UIButton *)sender {
    
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    TargetViewController *tvc;
    tvc=[segue destinationViewController];
    tvc.strNameLabel=self.textFieldName.text;
    tvc.strAddressLabel=self.textFieldAddress.text;
    tvc.strNumberLabel=self.textFieldNumber.text;
}
@end
