//
//  ViewController.h
//  DataTransfer
//
//  Created by Admin on 12/9/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *textFieldName;
@property (strong, nonatomic) IBOutlet UITextField *textFieldAddress;

@property (strong, nonatomic) IBOutlet UITextField *textFieldNumber;
- (IBAction)submitButton:(UIButton *)sender;

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender;

@end

