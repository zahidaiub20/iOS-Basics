//
//  ViewController.m
//  Segue
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
