//
//  main.m
//  If-ElseWithSwitch
//
//  Created by Azad on 9/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int stromCatagory=4;
        
        if(stromCatagory==1)
        {
            NSLog(@"Time to get indoors.");
        }
        if(stromCatagory==2)
        {
            NSLog(@"Extensive Damage- Run & Hide.");
        }
        if(stromCatagory==3)
        {
            NSLog(@"Devastating Damage.");
        }
        if(stromCatagory==4 || stromCatagory==5)
        {
            NSLog(@"Catastrophic damage! Game over");
        }
        if (stromCatagory <1 || stromCatagory>5)
        {
            NSLog(@"We have not encounterd this phenomenon before");
        }
        
        //Convert the following if conditions in switch statement;
        
        switch (stromCatagory) {
            case 1:
                NSLog(@"Time to get indoors.");
                break;
            case 2:
                NSLog(@"Extensive Damage- Run & Hide.");
                break;
            case 3:
                NSLog(@"Devastating Damage.");
                break;
            case 4:
            case 5:
                NSLog(@"Catastrophic damage! Game over");
                break;
                
            default:
                NSLog(@"We have not encounterd this phenomenon before");
                break;
        }
        //Increment & Decrement// Postfix and Prefix
        int a=5;
        NSLog(@"The value of a is %i",++a);
        NSLog(@"The value of a is %i",a++);
        
        //Ternary Operator
        int p1Score;
        int p2Score;
        //      Condition ? true: false
        int highScore=(p1Score > p2Score)? p1Score:p2Score;
        
        
        if (p1Score > p2Score) {
            highScore=p1Score;
        }
        else
        {
            highScore=p2Score;
        }
        
        
    }
    return 0;
}
