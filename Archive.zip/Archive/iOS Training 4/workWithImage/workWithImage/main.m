//
//  main.m
//  workWithImage
//
//  Created by Admin on 10/9/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"


@interface myInterface: NSObject
-(void) getName;
@end

@implementation myInterface
-(void)getName {
    NSLog(@"Hello Asif welcome to objecctive c area");
}
@end

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
        myInterface *interface = [[myInterface alloc] init];
        [interface getName];
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
