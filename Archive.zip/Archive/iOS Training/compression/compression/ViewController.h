//
//  ViewController.h
//  compression
//
//  Created by Admin on 23/9/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

