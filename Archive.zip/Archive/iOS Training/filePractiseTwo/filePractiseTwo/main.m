//
//  main.m
//  filePractiseTwo
//
//  Created by Azad on 17/10/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSFileManager *myFile=[NSFileManager defaultManager];
        
//        get documents directory
//NSUserDomainMask is used because we wanted to create a directory for only the user
        NSArray *directoryPaths=NSSearchPathForDirectoriesInDomains(NSMoviesDirectory, NSUserDomainMask, YES);
        
//        NSString *documentsDirectoryPath=[directoryPaths objectAtIndex:0];
//        if ([myFile fileExistsAtPath:@""]==YES) {
//            NSLog(@"file exists");
//        }
//            check if writable, readable and executable
        if ([myFile isWritableFileAtPath:@"/Users/azad/Desktop/file.pdf"]) {
            NSLog(@"is Writable");
        }
        if ([myFile isReadableFileAtPath:@"/Users/azad/Desktop/file.pdf"]) {
            NSLog(@"is Readable");
        }
        if ([myFile isExecutableFileAtPath:@"/Users/azad/Desktop/file.pdf"]) {
            NSLog(@"is Executable");
        }
        else
            NSLog(@"the file is not executable");
    }
    return 0;
}
