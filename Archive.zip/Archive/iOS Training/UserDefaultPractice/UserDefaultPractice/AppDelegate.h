//
//  AppDelegate.h
//  UserDefaultPractice
//
//  Created by Azad on 17/10/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

