//
//  main.m
//  filePractice
//
//  Created by Azad on 17/10/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        // insert code here...
//        NSLog(@"Hello, World!");
//        most file operations are done with NSFileManager
//        NSFileManager *myFile=[[NSFileManager alloc]init];
//        creating myFile using defaultManager class method.
        NSFileManager *myFile=[NSFileManager defaultManager];
        NSString *filePath=@"/Users/Admin/desktop/myText.txt";
        
//    Checking if the file exists
        if ([myFile fileExistsAtPath:filePath]) {
            NSLog(@"The file does exist");
        }
        else
        {
            NSLog(@"The file dosenot exists");
//            return 1;
        }
        
//        get an nsdictionary for attributes
        NSDictionary *fileAttributes=[myFile attributesOfItemAtPath:filePath error:nil];
        for (NSString *key in fileAttributes) {
            NSLog(@"the attribute key is %@ and the values is %@",key,fileAttributes[key]);
        }
    }
    return 0;
}
