//
//  main.m
//  LoadStringCmd
//
//  Created by Azad on 19/10/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        get the document directory
        NSURL *documentDir=[[NSFileManager defaultManager]URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
        
        //    create a full path
        NSURL *full=[documentDir URLByAppendingPathComponent:@"myText.txt"];
        
        //    load the ImmutableString
//        NSString *content=[[NSString alloc]initWithContentsOfURL:full encoding:NSUTF8StringEncoding error:nil];
        
//        load the mutableString
        NSMutableString *content=[[NSMutableString alloc]initWithContentsOfURL:full encoding:NSUTF8StringEncoding error:nil];
        
        //    write it out.
//        NSLog(@"The string is:%@",content);
        
//        new string
        [content appendString:@"Appended Happened"];
        
//        destination URL
        NSURL *saveLocation=[documentDir URLByAppendingPathComponent:@"AppendedBig.txt"];
        [content writeToURL:saveLocation atomically:YES encoding:NSUTF8StringEncoding error:nil];
        

    }
    return 0;
}
