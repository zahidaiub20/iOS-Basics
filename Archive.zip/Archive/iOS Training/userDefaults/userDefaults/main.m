//
//  main.m
//  userDefaults
//
//  Created by Admin on 5/11/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setInteger:9001 forKey:@"HighScore"];
        [defaults synchronize];
        NSInteger theHighScore = [defaults integerForKey:@"HighScore"];
        NSLog(@"the return value is %zd",theHighScore);
        
        //    To find the user Defaults path
        NSArray *path = NSSearchPathForDirectoriesInDomains(
                                                            NSLibraryDirectory, NSUserDomainMask, YES);
        NSString *folder = [path objectAtIndex:0];
        NSLog(@"Your NSUserDefaults are stored in this folder: %@/Preferences", folder);
        return YES;
    }
    return 0;
}
