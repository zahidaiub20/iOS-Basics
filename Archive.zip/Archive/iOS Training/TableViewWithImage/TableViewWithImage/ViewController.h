//
//  ViewController.h
//  TableViewWithImage
//
//  Created by Azad on 13/8/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource>


@end

