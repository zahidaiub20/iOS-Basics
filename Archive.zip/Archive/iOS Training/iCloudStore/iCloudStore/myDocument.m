//
//  myDocument.m
//  iCloudStore
//
//  Created by Azad on 20/10/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "myDocument.h"

@implementation myDocument

//It is the job of this method to collect the data to be stored in the document and to pass it back to the MyDocument object instance in the form of an NSData object.

-(id)contentsForType:(NSString *)typeName
               error:(NSError *__autoreleasing *)outError
{
    return [NSData dataWithBytes:[_userText UTF8String]
                          length:[_userText length]];
}

//The loadFromContents instance method is called by an instance of MyDocument when the object is instructed to read the contents of a file. This method is passed an NSData object containing the content of the document and is responsible for updating the application’s internal data structure accordingly. All this method needs to do, therefore, is convert the NSData object contents to a string and assign it to the userText object:

-(BOOL) loadFromContents:(id)contents
                  ofType:(NSString *)typeName
                   error:(NSError *__autoreleasing *)outError
{
    if ( [contents length] > 0) {
        _userText = [[NSString alloc]
                     initWithBytes:[contents bytes]
                     length:[contents length]
                     encoding:NSUTF8StringEncoding];
    } else {
        _userText = @"";
    }
    return YES;
} 

@end
