//
//  ViewController.m
//  iCloudStore
//
//  Created by Azad on 20/10/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
//the MyDocument class will require two methods that are responsible for interfacing between the MyDocument object instances and the application’s data structures.
//the contentsForType and loadFromContents methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    The ultimate goal of the application is to save any text in the text view to a document on the local file system of the device. When the application is launched it needs to check if the document exists and, if so, load the contents into the text view object. If, on the other hand, the document does not yet exist it will need to be created. As is usually the case, the best place to perform these tasks is the viewDidLoad method of the view controller.
    
//    The first task for the viewDidLoad method is to identify the path to the application’s Documents directory (a task outlined in Working with Directories on iOS 7) and construct a full path to the document which will be named document.doc. The method will then need to create an NSURL object based on the path to the document and use it to create an instance of the MyDocument class.
    
    NSArray *dirPaths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    
    NSString *docsDir = dirPaths[0];
    NSString *dataFile =[docsDir stringByAppendingPathComponent:@"document.doc"];
    
    _documentURL = [NSURL fileURLWithPath:dataFile];
    _document = [[myDocument alloc] initWithFileURL:_documentURL];
    _document.userText = @"";
    
//    The next task for the method is to create an NSFileManager instance and use it to identify whether the file exists. In the event that it does, the openWithCompletionHandler method of the MyDocument instance object is called to open the document and load the contents.
//    The openWithCompletionHandler allows for a code block to be written to which is passed a Boolean value indicating the success or otherwise of the file opening and reading process. On a successful read operation this handler code simply needs to assign the value of the userText property of the MyDocument instance (which has been updated with the document contents by the loadFromContents method) to the text property of the textView object, thereby making it visible to the user.
    
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    if ([filemgr fileExistsAtPath: dataFile])
    {
        [_document openWithCompletionHandler:
         ^(BOOL success) {
             if (success){
                 NSLog(@"Opened");
                 self.textView.text = self.document.userText;
             } else {
                 NSLog(@"Not opened");
             }
         }];
        
    } else {
//        In the event that the document does not yet exist, the saveToURL method of the MyDocument class will be called using the argument to create a new file:
        [_document saveToURL:_documentURL
            forSaveOperation: UIDocumentSaveForCreating
           completionHandler:^(BOOL success) {
               if (success){
                   NSLog(@"Created");
               } else {
                   NSLog(@"Not created");
               }
           }];
    }
    
}

//When the user touches the application’s save button the content of the text view object needs to be saved to the document. An action method has already been connected to the user interface object for this purpose and it is now time to write the code for this method.

- (IBAction)saveButton:(UIButton *)sender {
    
//    Since the viewDidLoad method has already identified the path to the document and initialized the document object, all that needs to be done is to call that object’s saveToURL method using the UIDocumentSaveForOverwriting option. The saveToURL method will automatically call the contentsForType method implemented previously in this chapter. Prior to calling the method, therefore, it is important that the userText property of the document object be set to the current text of the textView object.
    _document.userText = _textView.text;
    
    [_document saveToURL:_documentURL
        forSaveOperation:UIDocumentSaveForOverwriting
       completionHandler:^(BOOL success) {
           if (success){
               NSLog(@"Saved for overwriting");
           } else {
               NSLog(@"Not saved for overwriting");
           }
       }];
}
@end
