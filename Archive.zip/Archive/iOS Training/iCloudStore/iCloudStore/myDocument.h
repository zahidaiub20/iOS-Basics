//
//  myDocument.h
//  iCloudStore
//
//  Created by Azad on 20/10/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface myDocument : UIDocument
//The MyDocument class is a subclass of UIDocument.

@property (strong, nonatomic) NSString *userText;

//When an instance of MyDocument is created and the appropriate method is called on that instance to save the application’s data to a file, the class makes a call to its contentsForType instance method.
//It is the job of this method to collect the data to be stored in the document and to pass it back to the MyDocument object instance in the form of an NSData object.

@end

NS_ASSUME_NONNULL_END
