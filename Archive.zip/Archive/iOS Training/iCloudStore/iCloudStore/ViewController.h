//
//  ViewController.h
//  iCloudStore
//
//  Created by Azad on 20/10/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

//First, since we will be creating instances of the MyDocument class within the view controller it will be necessary to import the MyDocument.h file.
#import "myDocument.h"

@interface ViewController : UIViewController

//Secondly, both the viewDidLoad and saveDocument methods will need access to an NSURL object containing a reference to the document and also an instance of the MyDocument class
@property (strong, nonatomic) IBOutlet UITextView *textView;
- (IBAction)saveButton:(UIButton *)sender;

@property (strong, nonatomic) NSURL *documentURL;
@property (strong, nonatomic) myDocument *document;

@end

//Conflict Resolution and Document States
//The current state of a UIDocument subclass object may be identified by accessing the object’s documentState property. At any given time this property will be set to one of the following constants:
//UIDocumentStateNormal – The document is open and enabled for user editing.
//UIDocumentStateClosed – The document is currently closed. This state can also indicate an error in reading a document.
//UIDocumentStateInConflict – Conflicts have been detected for the document.
//UIDocumentStateSavingError – An error occurred when an attempt was made to save the document.
//UIDocumentStateEditingDisabled – The document is busy and is not currently safe for editing.

