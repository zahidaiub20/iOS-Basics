//
//  SearchViewController.h
//  DataTasksAndDownloadTasksInaRealWorldApplication
//
//  Created by Admin on 15/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController

<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

- (IBAction)cancel:(id)sender;

@end
