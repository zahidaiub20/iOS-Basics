//
//  ViewController.m
//  sessionDataTask
//
//  Created by Admin on 9/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    it is important to understand that the session object, an instance of NSURLSession, is the star player. It handles the requests and responses, configures the requests, manages session storage and state, etc. Creating a session can be done several ways. The quickest way to get started is to use NSURLSession's sharedSession class method
    NSURLSession *session = [NSURLSession sharedSession];
    
//    Create a Data Task
//    To query the search API, we need to send a request to https://itunes.apple.com/search and pass a few parameters
//    we invoke dataTaskWithURL:completionHandler: and pass it an instance of NSURL as well as a completion handler. The completion handler accepts three arguments, the raw data of the response (NSData), the response object (NSURLResponse), and an error object (NSError). If the request is successful, the error object is nil
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:[NSURL URLWithString:@"https://itunes.apple.com/search?term=apple&media=software"] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error)
                                      {
//                                          we know the request returns a JSON response, we create a Foundation object from the data object that we've received and log the output to the console.
                                          

        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSLog(@"%@", json);
    }];
    
//    A task has a state property that indicates whether the task is running (NSURLSessionTaskStateRunning), suspended (NSURLSessionTaskStateSuspended), canceling (NSURLSessionTaskStateCanceling), or completed (NSURLSessionTaskStateCompleted). When a session object creates a task, the task starts its life in the suspended state. To start the task, we need to tell it to resume by calling resume on the task.
    [dataTask resume];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
