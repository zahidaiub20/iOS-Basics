//
//  SearchViewController.h
//  RealLifeApplication
//
//  Created by Admin on 15/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UIScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (strong, nonatomic) NSURLSession *session;
@property (strong, nonatomic) NSURLSessionDataTask *dataTask;

@property (strong, nonatomic) NSMutableArray *podcasts;
@property (strong, nonatomic) NSDictionary *podcast;

- (IBAction)cancel:(id)sender;

@end
