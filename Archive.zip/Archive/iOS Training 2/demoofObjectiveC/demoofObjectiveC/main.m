//
//  main.m
//  demoofObjectiveC
//
//  Created by Admin on 12/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        
        NSArray *myArray;
        
    }
    return 0;
}
