//
//  ViewController.m
//  xyz
//
//  Created by Admin on 18/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UILabel *uidyuwfje;
@property (strong, nonatomic) IBOutlet UILabel *lkfhwjf;

@end

@implementation ViewController
- (IBAction)kjgheiugh:(UIButton *)sender {
}
- (IBAction)fihewfuewiu:(UIButton *)sender {
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)rghsg:(UIButton *)sender {
}
- (IBAction)ghiuehfiuer:(UIButton *)sender {
}

- (IBAction)kgjsd:(UIButton *)sender {
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    self.showlabel.text=self.textField.text;
}



@end
