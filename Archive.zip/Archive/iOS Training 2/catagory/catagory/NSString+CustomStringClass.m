//
//  NSString+CustomStringClass.m
//  catagory
//
//  Created by MacBook Air  on 26/9/18.
//  Copyright © 2018 mahmud. All rights reserved.
//

#import "NSString+CustomStringClass.h"

@implementation NSString (CustomStringClass)

-(NSString *) convertWhiteSpace
{
    NSString *myConvertedString= [self stringByReplacingOccurrencesOfString:@" " withString:@"/"];
    return myConvertedString;
}

@end
