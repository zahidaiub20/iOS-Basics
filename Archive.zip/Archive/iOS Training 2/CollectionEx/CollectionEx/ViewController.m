//
//  ViewController.m
//  CollectionEx
//
//  Created by Admin on 15/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSMutableArray *photoItem;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    photoItem=[[NSMutableArray alloc]initWithObjects:@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg",@"dog.jpg", nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return photoItem.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];

    UIImageView *storeImage=(UIImageView *)[cell viewWithTag:1];
    storeImage.image=[UIImage imageNamed:photoItem[indexPath.row]];
    
    return cell;
}
@end
