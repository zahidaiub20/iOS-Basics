//
//  ViewController.h
//  CollectionEx
//
//  Created by Admin on 15/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UICollectionViewDataSource>


@end

