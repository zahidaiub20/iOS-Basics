//
//  main.m
//  c
//
//  Created by Admin on 26/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "methodDemo.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        methodDemo *totalChocolate=[[methodDemo alloc]init];
        NSLog(@"Bhaiya and apu will give us tne mony that we need to buy chocolates %d",[totalChocolate multiplication:44 withAnotherNumber:5]);
    }
    return 0;
}
