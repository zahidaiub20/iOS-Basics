//
//  methodDemo.m
//  c
//
//  Created by Admin on 26/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import "methodDemo.h"
#import "chocolate.h"

@implementation methodDemo

-(int) multiplication:(int)num1 withAnotherNumber: (int)num2
{
    int total= num1*num2;
    return total;
}

@end
